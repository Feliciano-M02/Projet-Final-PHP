# Projet-Final-PHP
Création d'un clone de facebook (myChat).

Pojet réalisé par:
- d'ALMEIDA Feliciano Miguel
- ANAGONOU Richard
- AHOUANDJINOU Credo
- SENOU Michael 
    
    °Inormations Clients
        Nom: Feliciano
        Prénom: Miguel
        MDP: azerty
        Email: feliciano@gmail.com

    °Informations Admin 
        Nom: Anagonou
        Prénom: Richard
        MDP: qwerty
        Email: richard@gmail.com


